# 💌 Chat-Based Love Calculator

This is a fun Streamlit app that analyzes chat messages and calculates a love score based on:

- Sentiment
- Romantic words 💘
- Emojis 😍
- Reply time ⏱️

## How to Run

```bash
pip install -r requirements.txt
streamlit run app.py
```